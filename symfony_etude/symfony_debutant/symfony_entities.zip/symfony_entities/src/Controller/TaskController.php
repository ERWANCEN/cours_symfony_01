<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class TaskController extends AbstractController{
    // #[Route('/task', name: 'app_task')]
    public function index(string $bodyId): Response
    {
        return $this->render('task/index.html.twig', [
            'bodyId' => $bodyId,
        ]);
    }

    public function create(string $bodyId): Response
    {
        return $this->render('task/create.html.twig', [
            'bodyId' => $bodyId,
        ]);
    }
}
